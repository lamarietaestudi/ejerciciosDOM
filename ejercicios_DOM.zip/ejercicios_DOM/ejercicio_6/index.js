const deleteItem = document.querySelector('.fn-remove-me');
deleteItem.remove();
