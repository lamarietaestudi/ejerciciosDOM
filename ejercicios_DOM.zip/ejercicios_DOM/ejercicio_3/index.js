//! 1.1 Basandote en el array siguiente, crea una lista ul > li
//! dinámicamente en el html que imprima cada uno de los paises.
// Es el mismo ejercicio que el 2 (1.6)
const countries = ['Japón', 'Nicaragua', 'Suiza', 'Australia', 'Venezuela'];
const countriesList = document.createElement('ul'); //creo una lista vacía en el html
for (i = 0; i < countries.length; i++) {
  // recorremos el bucle porque en cada vuelta tiene que hacer unas acciones sobre cada elemento
  const country = document.createElement('li'); // declaro la variable country que contiene un elemento li
  country.textContent = countries[i]; // inserto dentro de cada li el elemento del array sobre el que está atacando el bucle
  countriesList.append(country); // inserto lo que obtengo dentro de la lista de países
}
console.log(countriesList);

//! 1.2 Elimina el elemento que tenga la clase .fn-remove-me.
const itemSelected = document.querySelector('.fn-remove-me'); // primero accedemos al dato
console.log(itemSelected); // comprobación por consola del dato
itemSelected.remove();

//! 1.3 Utiliza el array para crear dinamicamente una lista ul > li de elementos
//! en el div de html con el atributo data-function="printHere".
const cars = ['Mazda 6', 'Ford fiesta', 'Audi A4', 'Toyota corola'];
const myPrint = document.createElement('ul');
for (i = 0; i < cars.length; i++) {
  const car = document.createElement('li');
  car.textContent = cars[i];
  myPrint.append(car);
} // igual que en el ejercicio anterior, creamos la lista, creamos los li, ponemos cada elemento del array en un li, y luego todo junto dentro del ul
const printHere = document.querySelector('[data-function="printHere"]'); // marcamos al div que queremos atacar por su atributo
printHere.append(myPrint); //insertamos la lista que hemos creado dentro del div

//! 1.4 Crea dinamicamente en el html una serie de divs que contenga un elemento
//! h4 para el titulo y otro elemento img para la imagen.
// const countries2 = [
//   { title: 'Random title 1', imgUrl: 'https://picsum.photos/300/200?random=1' },
//   { title: 'Random title 2', imgUrl: 'https://picsum.photos/300/200?random=2' },
//   { title: 'Random title 3', imgUrl: 'https://picsum.photos/300/200?random=3' },
//   { title: 'Random title 4', imgUrl: 'https://picsum.photos/300/200?random=4' },
//   { title: 'Random title 5', imgUrl: 'https://picsum.photos/300/200?random=5' }
// ];

// for (i = 0; i < countries2.length; i++) {
//   const createDiv = document.createElement('div'); // creamos los divs para cada elemento del array
//   const createH4 = document.createElement('h4'); // creamos un h4
//   const createImg = document.createElement('img'); // creamos un img
//   createH4.textContent = countries2[i].title; // insertamos el valor de la clave en la etiqueta
//   createImg.src = countries2[i].imgUrl; // insertamos el valor de la clave en la etiqueta, como es una url usamos src
//   createDiv.append(createH4); // insertamos el h4 en el div
//   createDiv.append(createImg); // insertamos la img en el div
//   document.body.append(createDiv); // insertamos todo lo que hemos hecho en los pasos anteriores en el body para que se vea en el navegador (si no solo se ve por la consola)
//   console.log(createDiv); // comprobamos que todo lo que hemos hecho funciona
// }

//!  1.5 Basandote en el ejercicio anterior. Crea un botón que elimine el último
//! elemento de la serie de divs.

// const deleteButton = document.createElement('button'); // creamos el elemento botón, que se queda en el limbo
// deleteButton.textContent = 'Borrar'; // insertamos el texto del botón en el mismo
// document.body.appendChild(deleteButton); // insertamos el botón en el body del documento

// deleteButton.addEventListener('click', () => {
//   // creamos el evento click para el botón, con la función siguiente:
//   const listOfDivs = document.body.querySelectorAll('div'); // selecciona a todos los divs del body
//   if (listOfDivs.length > 0) {
//     // siempre que quede alguno en esa lista seleccionada
//     const lastDiv = listOfDivs[listOfDivs.length - 1]; // selecciona el que esté en última posición
//     lastDiv.remove(); // borrar ese elemento
//   }
// });

//! 1.6 Basandote en el ejercicio anterior. Crea un botón para cada uno de los
//! divs que elimine ese mismo elemento del html.
// entonces debería que crearlo dentro del bucle del 1.4, pero por no liarlo creo otro array con el mismo contenido, y sigo aquí

const superCountries = [
  { title: 'Random title 1', imgUrl: 'https://picsum.photos/300/200?random=1' },
  { title: 'Random title 2', imgUrl: 'https://picsum.photos/300/200?random=2' },
  { title: 'Random title 3', imgUrl: 'https://picsum.photos/300/200?random=3' },
  { title: 'Random title 4', imgUrl: 'https://picsum.photos/300/200?random=4' },
  { title: 'Random title 5', imgUrl: 'https://picsum.photos/300/200?random=5' }
];

for (i = 0; i < superCountries.length; i++) {
  const createDiv = document.createElement('div'); // creamos los divs para cada elemento del array
  const createH4 = document.createElement('h4'); // creamos un h4
  const createImg = document.createElement('img'); // creamos un img
  createH4.textContent = superCountries[i].title; // insertamos el valor de la clave en la etiqueta
  createImg.src = superCountries[i].imgUrl; // insertamos el valor de la clave en la etiqueta, como es una url usamos src
  createDiv.append(createH4); // insertamos el h4 en el div
  createDiv.append(createImg); // insertamos la img en el div
  document.body.append(createDiv); // insertamos todo lo que hemos hecho en los pasos anteriores en el body para que se vea en el navegador (si no solo se ve por la consola)
  const deleteButton = document.createElement('button'); // creamos el elemento botón, que se queda en el limbo
  deleteButton.textContent = 'Borrar solo este elemento'; // insertamos el texto del botón en el mismo
  document.body.appendChild(deleteButton); // insertamos el botón en el body del documento

  deleteButton.addEventListener('click', () => {
    // creamos el evento click para el botón, con la función siguiente:
    const listOfDivs = document.body.querySelectorAll('div'); // selecciona a todos los divs del body
    if (listOfDivs.length > 0) {
      // siempre que quede alguno en esa lista seleccionada
      const lastDiv = listOfDivs[listOfDivs.length - 1]; // selecciona el que esté en última posición
      lastDiv.remove(); // borrar ese elemento
      deleteButton.remove(); //hay que eliminar cada botón después del clic, porque sino se quedan ahí acumulados
    }
  });
}
