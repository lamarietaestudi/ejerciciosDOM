//! 1.1 Usa querySelector para mostrar por consola el botón con la clase .showme
console.log(document.querySelector('.showme').textContent);

//! 1.2 Usa querySelector para mostrar por consola el h1 con el id #pillado
console.log(document.querySelector('#pillado').textContent);

//! 1.3 Usa querySelector para mostrar por consola todos los p
const allMyP = document.querySelectorAll('p'); // selecciono todos los párrafos y los guardo en una variable, que es un array.
for (let myP of allMyP) {
  // para cada elemento de mi array, para cada párrafo de todos mis párrafos
  console.log(myP.textContent); // pinta el contenido de ese párrafo
}

//! 1.4 Usa querySelector para mostrar por consola todos los elementos con
//! la clase.pokemon
const allMyPoks = document.querySelectorAll('.pokemon');
for (let myPok of allMyPoks) {
  console.log(myPok.textContent);
} //es como el anterior pero en lugar de seleccionar por etiqueta, selecciono por clase

//! 1.5 Usa querySelector para mostrar por consola todos los elementos con
//! el atributo data-function="testMe".
const allElements = document.querySelectorAll('[data-function="testMe"]');
for (element of allElements) {
  console.log(element.textContent);
}
// Lo mismo que el anterior, pero accediendo al atributo de una etiqueta de html.

//! 1.6 Usa querySelector para mostrar por consola el 3 personaje con el atributo
//! data-function="testMe".
console.log(allElements[2].textContent); // la posición del tercer elemento es 2 /  0 -  1  - >> 2 <<
//aprovechando el código del punto 1.5, pinto en consola solo el que tiene la posición que quiero mostrar
