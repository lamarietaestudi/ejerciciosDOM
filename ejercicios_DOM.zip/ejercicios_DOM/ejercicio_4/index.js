// 1.1 Añade un botón a tu html con el id btnToClick y en tu javascript añade el
// evento click que ejecute un console log con la información del evento del click
const clickEvent = document.querySelector('#btnToClick'); // llamada al botón con el id indicado
clickEvent.addEventListener('click', () => {
  // añado el evento click al botón para que ejecute la función
  const printInfo = 'Has hecho click en el botón'; // mensaje para mostrar en el navegador
  const content = document.createElement('div'); // creo un div y lo asigno a la variable content
  content.textContent = printInfo; //indico que el contenido del div sea el mensaje guardado en la variable
  document.body.append(content); // añado el div al body del documento
});

// 1.2 Añade un evento 'focus' que ejecute un console.log con el valor del input.
const focusEvent = document.querySelector('.focus'); // llamada al input con la case focus
focusEvent.addEventListener('focus', () => {
  // añado el evento focus al input
  const focusContent = 'Has hecho focus aquí'; // declaro variable con el mensaje a mostrar en el input
  console.log(focusContent); // lo veo por consola, todo va bien
  focusEvent.value = focusContent; // cambio el valor del input por el mensaje
});

// 1.3 Añade un evento 'input' que ejecute un console.log con el valor del input.
const inputEvent = document.querySelector('.value'); // llamada al input con la clase value
const inputContent = document.createElement('div'); // creo un div para guardar lo que escribo, hay que crearlo fuera del evento sino se crearía un div con cada dígito que se escribe
inputEvent.addEventListener('input', () => {
  // añado el evento input al input
  inputContent.textContent = inputEvent.value; //pongo en el div lo que escribo
  document.body.append(inputContent); // inserto en el body del documento el div con lo que he escrito en el campo
});
