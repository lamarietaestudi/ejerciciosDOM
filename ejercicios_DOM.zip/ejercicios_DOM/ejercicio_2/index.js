//! 1.1 Inserta dinamicamente en un html un div vacio con javascript.
const myDiv = document.createElement('div');
console.log(myDiv);
//! 1.2 Inserta dinamicamente en un html un div que contenga una p con javascript.
const myDiv2 = document.createElement('div');
const myParagrph = document.createElement('p');
myDiv2.append(myParagrph);
console.log(myDiv2);

//! 1.3 Inserta dinamicamente en un html un div que contenga 6 p utilizando un
//! 	loop con javascript.
const myDiv3 = document.createElement('div');
for (let i = 0; i < 6; i++) {
  myDiv3.append(document.createElement('p'));
}
console.log(myDiv3);

//! 1.4 Inserta dinamicamente con javascript en un html una p con el
//! 	texto 'Soy dinámico!'.
const dinamicTxt = document.createElement('p');
dinamicTxt.textContent = 'Soy dinámico!';
console.log(dinamicTxt);

//! 1.5 Inserta en el h2 con la clase .fn-insert-here el texto 'Wubba Lubba dub dub'.
const myH2 = document.querySelector('h2.fn-insert-here');
myH2.textContent = 'Wubba Lubba dub dub';
console.log(myH2);
//? En consola veo esto <h2 class="fn-insert-here">Wubba Lubba dub dub</h2>, pero en el navegador se ve bien.
//! 1.6 Basandote en el siguiente array crea una lista ul > li con
//! los textos del array.
const apps = ['Facebook', 'Netflix', 'Instagram', 'Snapchat', 'Twitter'];
const appList = document.createElement('ul');
for (i = 0; i < apps.length; i++) {
  const appName = document.createElement('li');
  appName.textContent = apps[i];
  appList.append(appName);
}
console.log(appList);

//! 1.7 Elimina todos los nodos que tengan la clase .fn-remove-me
const elementsList = document.querySelectorAll('.fn-remove-me');
for (element of elementsList) {
  element.remove();
}
console.log(elementsList);

//! 1.8 Inserta una p con el texto 'Voy en medio!' entre los dos div.
//! 	Recuerda que no solo puedes insertar elementos con .appendChild.
const middleItem = document.createElement('p'); // creo un elemento P
middleItem.textContent = 'Voy en medio!'; // le añado al p el contenido de texto
// según el enunciado entiendo que hay que colocar ese p entre los divs que tienen la clase fn-insert-here.
const classInsertItems = document.body.querySelectorAll('.fn-insert-here'); // selecciono los elementos que tienen esa clase solamente
console.log(classInsertItems); // verifico por consola que están seleccionados y son 3 elementos (length:3)
if (classInsertItems.length >= 2) {
  // si el número de elementos que tiene esta clase es 2 o más
  classInsertItems[1].insertAdjacentElement('beforeend', middleItem); // selecciono el segundo elemento de esa lista de elementos, e inserto el párrafo que he creado antes
}
//dentro de los divs he añadido texto en el html para ver que quedaba en el medio. Veo que con el ejercicio 1.9 se va a sobreescribir
//! 1.9 Inserta p con el texto 'Voy dentro!', dentro de todos los div con la clase
//! 	.fn-insert-here
const myText = document.createElement('p');
myText.textContent = 'Voy dentro!';
const mySelection = document.querySelectorAll('.fn-insert-here');
for (item of mySelection) {
  item.appendChild(myText.cloneNode(true));
}
// desconocía el método cloneNode, porque no sabía que un elemento solo podía estar en una sola parte del DOM. Parece que en lugar de ponerlo en cada div lo estaba moviendo de uno a otro y se quedaba en el último. Entiendo el concepto, pero sin la ayuda de ChatGPT no lo habría descubierto.
