// Utiliza el array para crear dinamicamente una lista ul > li de elementos en el div de html con el atributo data-function="printHere".
const places = ['Gondor', 'Mordor', 'Rivendel', 'La Comarca', 'Nümenor'];
const listPlaces = document.createElement('ul');
for (place of places) {
  const contentPlace = document.createElement('li');
  contentPlace.textContent = place;
  contentPlace.setAttribute('data-function', 'print-here');
  listPlaces.append(contentPlace);
}
document.body.append(listPlaces);
console.log(listPlaces);
